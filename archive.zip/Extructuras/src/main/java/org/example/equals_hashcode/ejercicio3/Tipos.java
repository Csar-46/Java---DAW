package main.java.org.example.equals_hashcode.ejercicio3;

public enum Tipos {

    ADMINISTRATIVO,EMPRESARIAL,PERSONAL

}
