package org.example.pokedex;

public class Rayo extends Pokemon{

    public Rayo(int nivel) {

        super(nivel);

    }

    @Override
    public void atacar() {

        System.out.println("IMPACTRUENOOOOO");

    }
}
