package org.example.pokedex;

public interface AtaquesAgua {

    void pistolaAgua();

    void sapicadura();

    void surf();

    void hidrobombra();

    void cascada();

}
