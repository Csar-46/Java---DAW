package org.example.empresa;

public class Desarrollador extends Empleado{

    public void realizarTarea(){

        System.out.println("Escribiendo código y solucionando bugs.");

    }

}
