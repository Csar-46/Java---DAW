package org.example.empresa;

public class Disenyador extends Empleado{

    public void realizarTarea(){

        System.out.println("Creando diseños gráficos y prototipos.");

    }

}
