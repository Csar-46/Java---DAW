package org.example.empresa;

public class Empleado {

    public void realizarTarea(){

        System.out.println("Empleado realizando una tarea genérica.");

    }

}
