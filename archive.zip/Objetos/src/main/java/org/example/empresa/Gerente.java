package org.example.empresa;

public class Gerente extends Empleado{

    public void realizarTarea(){

        System.out.println("Supervisando el proyecto y organizando reuniones.");

    }

}
