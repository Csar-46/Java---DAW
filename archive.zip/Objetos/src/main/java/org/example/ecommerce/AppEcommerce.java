package org.example.ecommerce;

public class AppEcommerce {

    public static void main(String[] args){

        //Invocamos al metodo iniciarPago de la clase Tienda.
        Tienda.iniciarPago();

    }
}
