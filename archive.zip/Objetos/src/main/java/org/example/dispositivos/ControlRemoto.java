package org.example.dispositivos;

public interface ControlRemoto {

    void sincronizar();

}
