package org.example.practica2;

public class ComprobarDorsal extends RuntimeException {

    public ComprobarDorsal() {
        super("Lo tienes repe chaval.");
    }
}
