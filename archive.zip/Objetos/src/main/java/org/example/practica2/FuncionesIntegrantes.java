package org.example.practica2;

public interface FuncionesIntegrantes {

    void concentrarse();

    void viajar(String cuidad);

    void celebrarGol();

}
