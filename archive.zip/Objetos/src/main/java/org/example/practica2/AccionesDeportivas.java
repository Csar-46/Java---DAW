package org.example.practica2;

public interface AccionesDeportivas {

    void entrenar();

    void jugarpartidos(String rival);

}
