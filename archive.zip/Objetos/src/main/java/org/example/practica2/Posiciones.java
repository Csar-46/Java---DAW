package org.example.practica2;

public enum Posiciones {

    PORTERO,DEFENSA,CENTROCAMPISTA,DELANTERO

}
