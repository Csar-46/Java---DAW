package org.example.practica2;

public class FormacionIncorrecta extends RuntimeException {
    public FormacionIncorrecta() {
        super("Que clase de formacion es esa bobi?");
    }
}
