package org.example.practica2;

public enum Equipos {

    BENJAMIN,ALEVIN,INFANTIL,CADETE,JUVENIL,SENIOR

}
