package org.example.festival;

public interface Promocionable {

    void Promocionar();

}
