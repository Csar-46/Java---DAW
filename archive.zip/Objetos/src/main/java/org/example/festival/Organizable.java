package org.example.festival;

public interface Organizable {

    void OrganizarEvento();

}
